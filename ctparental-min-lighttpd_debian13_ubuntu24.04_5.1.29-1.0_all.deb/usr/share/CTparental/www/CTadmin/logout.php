<html>
    <head>
        <title>CTparental DNS filtering</title>
        
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">
        <link rel="stylesheet" href="css/main.css" type="text/css">
        <link rel="stylesheet" href="css/sticky-footer.css" type="text/css">
        <link rel="stylesheet" href="css/dashboard.css" type="text/css">
        
        <script src="js/jquery-1.12.3.min.js"></script>
        <script src="js/bootstrap.min.js"></script>
    </head>

    <body>
<?php 
    include 'locale.php';
    echo "<h1 class='page-header'>".gettext('You are disconected')."</h1>";
?>


    </body>
</html>
